<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Skyview Pollution</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <link rel="stylesheet" href="styles.css">
        <script src="aaa.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    </head>
    <header class="topo" style="height: 100px; width: 100%; background-color: darkblue; border-bottom: 3px solid yellow;">
        <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <h3 class="title" style="color: yellow; font-family: fantasy; font-size: 50px; margin-top: 17px; margin-left: -30px;">SKYVIEW POLLUTION</h3>
            <h3 class="title" style="color: yellow; font-family: fantasy; font-size: 20px; margin-top: 41px; margin-left: 10px;">PORTO ALEGRE</h3>
        </div>
        <div class="hamburgermenu" onclick="myFunction(this)">
            <div class="bar1"></div>
            <div class="bar2"></div>
            <div class="bar3"></div>
        </div>
    </header>

    <body>
        <div class="skyview">
            <img style="display:block; position:relative; height: 500px; width: 100%; border-bottom: 3px solid yellow;" src="http://rodademocratica.com.br/wp-content/uploads/2018/06/milky-way-starry-sky-night-sky-star-956981-1.jpeg">
            <img style="display:block; position:absolute; top: 100px; height: 500px; width: 100%; border-bottom: 3px solid yellow;" src="https://images.unsplash.com/photo-1544656376-ffe19d4b7353?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8YmxhY2slMjBza3l8ZW58MHx8MHx8&w=1000&q=80">
        </div>

        <div class="slidecontainer">
            <input type="range" min="1" max="100" value="50" class="slider" id="myRange">
        </div>

        <div class="fullscreen">
            <b><a class="fullscreenbtn" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="black" class="bi bi-fullscreen" viewBox="0 0 16 16">
                <path d="M1.5 1a.5.5 0 0 0-.5.5v4a.5.5 0 0 1-1 0v-4A1.5 1.5 0 0 1 1.5 0h4a.5.5 0 0 1 0 1h-4zM10 .5a.5.5 0 0 1 .5-.5h4A1.5 1.5 0 0 1 16 1.5v4a.5.5 0 0 1-1 0v-4a.5.5 0 0 0-.5-.5h-4a.5.5 0 0 1-.5-.5zM.5 10a.5.5 0 0 1 .5.5v4a.5.5 0 0 0 .5.5h4a.5.5 0 0 1 0 1h-4A1.5 1.5 0 0 1 0 14.5v-4a.5.5 0 0 1 .5-.5zm15 0a.5.5 0 0 1 .5.5v4a1.5 1.5 0 0 1-1.5 1.5h-4a.5.5 0 0 1 0-1h4a.5.5 0 0 0 .5-.5v-4a.5.5 0 0 1 .5-.5z"/>
            </svg></a></b>
        </div>

        <div class="info">
            <img class="pizzagraph" src="https://cdn-icons-png.flaticon.com/512/1170/1170601.png"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum nibh ac magna egestas laoreet sit amet at ipsum. Nunc sodales ante eget tempus lacinia. Nunc pulvinar efficitur mi. Ut vitae pharetra ipsum. Donec volutpat dolor sit amet vulputate porta. In pretium tempor dui, quis dignissim magna sagittis id. Aenean justo mi, porttitor et velit sed, dapibus vestibulum velit.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum nibh ac magna egestas laoreet sit amet at ipsum. Nunc sodales ante eget tempus lacinia. Nunc pulvinar efficitur mi. Ut vitae pharetra ipsum. Donec volutpat dolor sit amet vulputate porta. In pretium tempor dui, quis dignissim magna sagittis id. Aenean justo mi, porttitor et velit sed, dapibus vestibulum velit.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum nibh ac magna egestas laoreet sit amet at ipsum. Nunc sodales ante eget tempus lacinia. Nunc pulvinar efficitur mi. Ut vitae pharetra ipsum. Donec volutpat dolor sit amet vulputate porta. In pretium tempor dui, quis dignissim magna sagittis id. Aenean justo mi, porttitor et velit sed, dapibus vestibulum velit.</p>
            <img class="bargraph" src="https://images.vexels.com/media/users/3/143065/isolated/preview/c6cbc8cf5ca3856bca8d5f28c0471fca-carrinho-de-grafico-de-barras.png">
        </div>
    </body>
</html>